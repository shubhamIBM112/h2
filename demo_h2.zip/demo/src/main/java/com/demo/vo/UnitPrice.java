package com.demo.vo;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"currencyCode",
"units",
"nanos"
})
public class UnitPrice {

@JsonProperty("currencyCode")
private String currencyCode;
@JsonProperty("units")
private String units;
@JsonProperty("nanos")
private Integer nanos;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("currencyCode")
public String getCurrencyCode() {
return currencyCode;
}

@JsonProperty("currencyCode")
public void setCurrencyCode(String currencyCode) {
this.currencyCode = currencyCode;
}

@JsonProperty("units")
public String getUnits() {
return units;
}

@JsonProperty("units")
public void setUnits(String units) {
this.units = units;
}

@JsonProperty("nanos")
public Integer getNanos() {
return nanos;
}

@JsonProperty("nanos")
public void setNanos(Integer nanos) {
this.nanos = nanos;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}
