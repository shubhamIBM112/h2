package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.utility.HttpExternalConnection;
import com.demo.vo.Vo;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.type.TypeReference;

@RestController
public class ParseAndSaveToDB {


	@Autowired
	ObjectMapper mapper;


	@GetMapping("/home")
	public void checkMethod(){
		System.out.println("Hello");
	}

	@PostMapping("/saveToDb")
	public void saveDataInDb(){
		String url = "https://cloudbilling.googleapis.com/v1/services/6F81-5844-456A/skus?key=AIzaSyD9XNBAF4BrEhgL47t3P7FmPTF0EAvArnY";
		HttpExternalConnection httpExternalConnection = new HttpExternalConnection();
		String output = httpExternalConnection.sendAndReceiveGet(url);
		Vo vo = new Vo();
		System.out.println(output);
		try{
			if(output!=""){
				mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
				vo =mapper.readValue(output, new TypeReference<Vo>(){
				});
			}}catch(Exception e){
				e.printStackTrace();
			}

		System.out.println(vo.getNextPageToken());
		

	}
}
